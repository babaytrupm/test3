import { Plugin } from "@ai16z/eliza";

export const starknetPlugin: Plugin = {
    name: "starknet",
    description: "Starknet Plugin for Eliza",
    actions: [
        // TODO: Add actions like swap, etc.
    ],
    evaluators: [],
    providers: [],
};

export default starknetPlugin;
