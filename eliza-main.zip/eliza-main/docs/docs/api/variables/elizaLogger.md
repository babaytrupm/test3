# Variable: elizaLogger

> `const` **elizaLogger**: `ElizaLogger`

## Defined in

[packages/core/src/logger.ts:282](https://github.com/ai16z/eliza/blob/7fcf54e7fb2ba027d110afcc319c0b01b3f181dc/packages/core/src/logger.ts#L282)
