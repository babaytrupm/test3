# Variable: embeddingDimension

> `const` **embeddingDimension**: `1536` = `1536`

## Defined in

[packages/core/src/memory.ts:9](https://github.com/ai16z/eliza/blob/7fcf54e7fb2ba027d110afcc319c0b01b3f181dc/packages/core/src/memory.ts#L9)
