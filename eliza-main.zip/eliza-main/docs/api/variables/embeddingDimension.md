[@ai16z/eliza v1.0.0](../index.md) / embeddingDimension

# Variable: embeddingDimension

> `const` **embeddingDimension**: `1536` = `1536`

## Defined in

[packages/core/src/memory.ts:9](https://github.com/ai16z/eliza/blob/main/packages/core/src/memory.ts#L9)
