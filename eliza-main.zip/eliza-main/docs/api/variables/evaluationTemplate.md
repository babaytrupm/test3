[@ai16z/eliza v1.0.0](../index.md) / evaluationTemplate

# Variable: evaluationTemplate

> `const` **evaluationTemplate**: `string`

Template used for the evaluation generateText.

## Defined in

[packages/core/src/evaluators.ts:8](https://github.com/ai16z/eliza/blob/main/packages/core/src/evaluators.ts#L8)
