[@ai16z/eliza v1.0.0](../index.md) / stringToUuid

# Function: stringToUuid()

> **stringToUuid**(`target`): [`UUID`](../type-aliases/UUID.md)

## Parameters

• **target**: `string`

## Returns

[`UUID`](../type-aliases/UUID.md)

## Defined in

[packages/core/src/uuid.ts:4](https://github.com/ai16z/eliza/blob/main/packages/core/src/uuid.ts#L4)
