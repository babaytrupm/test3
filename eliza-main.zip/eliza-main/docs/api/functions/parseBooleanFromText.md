[@ai16z/eliza v1.0.0](../index.md) / parseBooleanFromText

# Function: parseBooleanFromText()

> **parseBooleanFromText**(`text`): `boolean`

## Parameters

• **text**: `string`

## Returns

`boolean`

## Defined in

[packages/core/src/parsing.ts:36](https://github.com/ai16z/eliza/blob/main/packages/core/src/parsing.ts#L36)
